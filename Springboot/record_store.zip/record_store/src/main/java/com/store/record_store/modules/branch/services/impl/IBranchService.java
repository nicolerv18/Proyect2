package com.store.record_store.modules.branch.services.impl;

import java.util.List;

import com.store.record_store.modules.branch.dto.BranchRequestDto;
import com.store.record_store.modules.branch.dto.BranchResponseDto;

public interface IBranchService {

    /*
    create
    update
    partial
    delete logic
    delete
    */

    public BranchResponseDto create(BranchRequestDto requestDto);
    public List<BranchResponseDto> findAll(String filter);
    public BranchResponseDto findById(Long id);
}